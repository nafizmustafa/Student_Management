from odoo import models, fields

class Student(models.Model):
    _name = 'student.management.student'
    _description = 'Student'

    name = fields.Char(string='Name', required=True)
    email = fields.Char(string='Email')
    roll_no = fields.Char(string='Roll No')
    department = fields.Char(string='Department')
    course_ids = fields.Many2many(
        'student.management.course',
        'student_course_rel',
        'student_id', 'course_id',
        string='Courses'
    )

    def action_show_enrolled_courses(self):
        self.ensure_one()
        action = self.env.ref('student_management.action_course').read()[0]
        action.update({
            'domain': [('id', 'in', self.course_ids.ids)],
            'context': {'default_student_ids': [(4, self.id)]},
        })
        return action
