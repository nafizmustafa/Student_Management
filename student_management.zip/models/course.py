from odoo import models, fields

class Course(models.Model):
    _name = 'student.management.course'
    _description = 'Course'

    name = fields.Char(string='Course Name', required=True)
    code = fields.Char(string='Course Code')
    credit = fields.Integer(string='Credit')
    student_ids = fields.Many2many(
        'student.management.student',
        'student_course_rel',
        'course_id', 'student_id',
        string='Students'
    )

    def action_print_student_list(self):
        return self.env.ref('student_management.report_student_course').report_action(self)
