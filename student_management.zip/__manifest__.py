{
    'name': 'Student Management',
    'summary': 'Manage students and courses',
    'version': '1.0',
    'category': 'Education',
    'author': 'Your Name',
    'license': 'LGPL-3',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/menu_views.xml',
        'views/student_views.xml',
        'views/course_views.xml',
        'report/report_student_course.xml',
    ],
    'installable': True,
    'application': True,
}